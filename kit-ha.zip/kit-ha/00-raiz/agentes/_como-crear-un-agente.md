# Cómo crear un agente

Un **agente** en HA es una voz o un lente con un encargo claro: una nota que describe cómo debe pensar el asistente cuando lo convocas. Sirve para mirar un problema desde un ángulo específico —legal, financiero, técnico, de riesgo— y tenerlo a la mano cada vez.

El kit trae los **agentes de arquitectura**: la **raíz**, que coordina y mira el conjunto, y los **seis de dimensión** (legado, comunidad, aprendizaje, tecnología, contexto, proyectos), que piensan cada uno desde su ángulo. Trae también dos transversales: **revisión crítica** y **primeros principios**. Sobre esa base creas los que cada proyecto pida.

Crea un agente nuevo cuando un proyecto pida una mirada que se va a repetir. Cuando la necesitas una sola vez, basta con pedirla en el momento.

---

## Plantilla

Copia este molde en un archivo nuevo dentro de `00-raiz/agentes/`, con nombre en minúsculas y guiones (por ejemplo, `mirada-financiera.md`).

```
# Agente: <nombre>

**Propósito:** qué aporta esta voz que las demás no.

**Cuándo convocarlo:** la clase de pregunta o decisión en la que ayuda.

**Cómo se comporta:** la actitud y el método. Qué prioriza al mirar.

**Qué evita:** los sesgos o excesos en los que no debe caer.
```

---

Esta plantilla es el mínimo. Los **seis agentes de dimensión** (`legado`, `comunidad`, `aprendizaje`, `tecnología`, `contexto`, `proyectos`) usan una forma más amplia —su pregunta de fondo, qué mira y produce, cómo se lee en el tiempo, y cómo se relaciona con las otras cinco— porque cargan el método completo. Léelos como ejemplo cuando quieras un agente más desarrollado; para una mirada puntual, el molde de arriba basta.

## Reglas

- Un agente tiene un solo encargo. Si hace de todo, no aporta foco.
- Los agentes proponen; las personas deciden.
- Un agente puede equivocarse: su valor está en el ángulo que aporta. La última palabra es de la persona.
- Cuando convocas varios a la vez sobre una misma decisión, eso es un **consejo** (ver la habilidad `consejo`).
