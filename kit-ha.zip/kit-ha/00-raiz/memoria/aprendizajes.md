# Aprendizajes

Las lecciones que el trabajo va dejando. El relato de cada sesión vive en la memoria de trabajo; aquí se guarda lo que conviene recordar para la próxima. Una lección por línea, con fecha.

> Plantilla:

```
[fecha] APRENDIZAJE: lo que se entendió. | DE DÓNDE: la situación que lo enseñó.
```

Una lección entra aquí cuando es transferible: aplica a más de un caso, no solo al de hoy.

---

## Lecciones

(Aún no hay aprendizajes registrados.)
