# Contexto

La memoria de fondo del sistema. Se organiza en tres zonas, de lo más estable a lo más cambiante. HA la lee al empezar y la actualiza al cerrar.

---

## Zona A — Identidad (fija)

Lo que casi no cambia: quién es el dueño de esta HA y cuál es su alcance.

- **Dueño:** (persona, equipo u organización que adopta este kit)
- **Alcance:** (qué entra y qué no entra en el trabajo de esta HA)
- **Idioma de trabajo:** español

> Completa estos campos en la primera sesión. Después casi no se tocan.

---

## Zona B — Criterio (evoluciona)

Lo que el sistema aprende a lo largo del tiempo y conviene conservar: decisiones tomadas, patrones que funcionan, correcciones recibidas. Cada entrada lleva fecha.

### Decisiones
- (Ninguna todavía. Formato: `[fecha] DECISIÓN: … | PORQUÉ: … | ESTADO: vigente`)

### Patrones
- (Ninguno todavía. Formato: `[fecha] PATRÓN: … | EJEMPLO: …`)

### Correcciones
- (Ninguna todavía. Formato: `[fecha] CORRECCIÓN: … | LECCIÓN: …`)

---

## Zona C — Estado actual (cambia seguido)

La foto de hoy: qué está abierto, qué espera respuesta, cuál es el siguiente paso.

- **Proyectos activos:** (ninguno todavía)
- **Pendientes:** (ninguno todavía)
- **Esperando respuesta de:** (nadie todavía)
- **Siguiente paso:** (por definir)

> Esta zona se reescribe al cerrar cada sesión. No se acumula: refleja el presente.
