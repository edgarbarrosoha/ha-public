# Memoria de trabajo

El registro de las sesiones, de la más reciente a la más antigua. Cada vez que cierras una sesión, agregas una entrada arriba. Sirve para retomar sin perder el hilo.

> Plantilla de entrada (copia el bloque y llénalo al cerrar):

```
### [fecha] | Sesión N | Título corto
- Foco: en qué se trabajó.
- Avances: qué quedó hecho.
- Decisiones: qué se resolvió y por qué.
- Pendientes: qué quedó abierto.
- Siguiente: por dónde seguir la próxima vez.
```

---

## Sesiones

(Aún no hay sesiones registradas. La primera entrada se escribe al cerrar la primera sesión.)
