# Glosario de Arquitectura de Horizontes

Los términos que vale la pena hacer propios. Son el vocabulario común del método: cuando un equipo los usa de la misma forma, deja de discutir cómo estructurar el trabajo y pasa a hacerlo.

**Arquitectura de Horizontes (HA).** Una estructura compartida para navegar la complejidad en alianza entre las personas y la inteligencia artificial. Mira cualquier trabajo a través de seis dimensiones y dos ejes, con la misma forma a cualquier escala, de una tarea a una organización.

**Las seis dimensiones.** Legado, Comunidad, Aprendizaje, Tecnología, Contexto y Proyectos. Cada una responde una pregunta distinta y todas operan a la vez.

**Los dos ejes.** El tiempo (pasado, presente, futuro como clasificación viva) y la complejidad simultánea (las seis dimensiones coordinándose entre sí).

**Complejidad simultánea.** El principio de que las dimensiones no se atienden una por una, sino juntas: un cambio en una toca a las demás.

**Estructura fractal.** La misma forma —seis dimensiones, dos ejes— se repite en una tarea, un proyecto, un área y la organización entera.

**Los tres axiomas.** Lo que se asume como dado: las seis dimensiones siempre están; el tiempo es no lineal; la estructura es fractal. No se rediscute en cada caso.

**Función de legado.** La definición de qué significa ganar: el objetivo, su horizonte de tiempo y, cuando se puede, cómo se mide. Gobierna las decisiones de un proyecto.

**Ontología generativa.** La capacidad del sistema de crear lo que le falta —una habilidad, un agente— cuando un trabajo nuevo lo pide, sin rehacer la estructura.

**Trazabilidad.** Que cada afirmación que sostiene una decisión pueda seguirse hasta su fuente, su fecha y el proceso que la produjo.

**Memoria.** Lo que el sistema conserva entre sesiones: el contexto (identidad, criterio y estado), el registro de trabajo y los aprendizajes.

**Habilidad.** Un procedimiento repetible escrito como nota, para no improvisar cada vez un trabajo que se repite.

**Agente.** Una voz o un lente con un encargo claro, que se convoca para mirar un problema desde un ángulo específico.

**CREATIVO.** Una forma de armar una instrucción para un modelo de IA: Contexto, Rol, Ejemplo, Audiencia, Tarea, Instrucciones, Voz, Objetivo. Detalle en `03-aprendizaje/creativo.md`.

**Escalar (acercar y alejar).** Mirar el mismo trabajo a distinto nivel: una sola tarea, un proyecto, un área, la organización. La estructura no cambia; cambia el alcance.
