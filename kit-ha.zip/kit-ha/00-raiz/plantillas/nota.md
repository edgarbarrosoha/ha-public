# Plantilla de nota

Molde para guardar contexto: una reunión, una llamada, una idea, un documento que llegó. Las notas son material de contexto; los entregables se guardan en la carpeta del proyecto. Guarda cada nota en la dimensión que le corresponde (con frecuencia `05-contexto/` o dentro de la carpeta del proyecto).

---

# Nota: <título>

**Fecha:** <fecha>
**Origen:** <de dónde viene: reunión, llamada, lectura, idea>
**Relacionada con:** <proyecto o dimensión, si aplica>

## Contenido
Lo que importa conservar, en limpio.

## Qué hacer con esto
- (Acciones o pendientes que salen de la nota, si los hay.)
