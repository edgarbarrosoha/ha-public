# Plantilla de proyecto

Molde para un proyecto nuevo. La habilidad `nuevo-proyecto` la copia a una subcarpeta dentro de `06-proyectos/` y la llena contigo. Cada proyecto repite las seis dimensiones a su escala.

---

# Proyecto: <nombre>

**Fecha de inicio:** <fecha>
**Dueño:** <quién responde por este proyecto>
**Estado:** en definición

## Qué es ganar (Legado del proyecto)
Una o dos frases sobre el resultado que importa y en qué horizonte de tiempo. Si se puede, qué se mediría para saber que se logró.

## Las seis dimensiones

- **01 Legado.** El objetivo que trasciende a este proyecto. Por qué vale la pena.
- **02 Comunidad.** Quién decide, quién participa y quién se beneficia.
- **03 Aprendizaje.** Qué hay que saber o aprender para lograrlo. Qué falta.
- **04 Tecnología.** Qué herramientas, datos o infraestructura se usan.
- **05 Contexto.** Qué condiciones externas lo afectan (mercado, reglas, tiempos).
- **06 Proyectos.** Las tareas concretas, los entregables y los plazos.

## Primeros entregables
- (Qué se produce primero y para cuándo.)

## Riesgos
- (Qué podría salir mal y cómo se cubriría.)

## Bitácora
- <fecha> — Proyecto creado.
