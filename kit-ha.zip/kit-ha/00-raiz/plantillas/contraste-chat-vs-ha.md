# Plantilla de contraste: chat frente a entorno HA

Una hoja para ver, en tu propio proyecto, qué cambia al pasar de un chat suelto a un entorno con método. Toma una pregunta de tu proyecto y hazla en los dos lados.

---

**Proyecto:** <nombre>
**La pregunta:** <una pregunta real de tu proyecto>

| | Chat genérico | Entorno HA |
|---|---|---|
| Respuesta | <qué te dio> | <qué te dio> |
| ¿De dónde salió? | <rastro y fuente> | <rastro y fuente> |
| ¿Sigue mañana? | <se pierde / queda en la memoria> | <se pierde / queda en la memoria> |

**Qué apareció con la arquitectura:**
- **Rastro** — <cada dato a su fuente y su fecha>
- **Memoria** — <el avance queda y la próxima sesión retoma>
- **Cruce** — <una dimensión o un riesgo que el chat no miró>
