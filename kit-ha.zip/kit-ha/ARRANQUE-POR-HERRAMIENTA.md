# Arranque por herramienta

Cómo poner en marcha el kit según el asistente de IA que uses. En todos los casos el objetivo es el mismo: que el asistente lea la carpeta, adopte la identidad de `00-raiz/eres-ha.md` y luego ejecute el *prompt de arranque* de `EMPIEZA-AQUI.md`.

> **El camino corto para cualquier chat:** la mayoría de los chats no aceptan carpetas, solo archivos sueltos. Por eso el kit viene también como un archivo único, `kit-architect.md`, con todo el contenido adentro. Un archivo, un upload, y el prompt de arranque. Si tu herramienta sí acepta varios archivos o carpetas, las vías de abajo siguen valiendo.

---

## Antes de empezar, una prueba de un minuto

Confirma que tu asistente puede leer la carpeta: súbela —o pega `00-raiz/eres-ha.md`— y pídele «resume en una línea qué es Arquitectura de Horizontes según este archivo». Si responde con el contenido del archivo, está listo.

Si no lo ve —por permisos, políticas de datos o un Copilot restringido por tu organización—, usa la vía de pegar archivos sueltos, o pide a tu área de TI acceso a la carpeta antes de la sesión. Conviene resolver esto antes, no en vivo.

---

## Claude (claude.ai)

1. Crea un **Proyecto** (plan de pago) y sube `kit-architect.md` al conocimiento del proyecto — o adjúntalo directo en un chat si no usas Proyectos.
2. Pega el prompt de arranque como primer mensaje.
3. Ventaja del Proyecto: el kit queda disponible en todas las conversaciones de ese proyecto, sin volver a subirlo. Los avances igual hay que copiarlos de vuelta a tus archivos al cerrar.

## ChatGPT (chatgpt.com)

1. Crea un **Proyecto** y sube `kit-architect.md` a sus archivos — o adjúntalo en una conversación normal.
2. Pega el prompt de arranque como primer mensaje.
3. El número de archivos por proyecto depende del plan (en el plan gratuito son pocos); con el archivo único no topas con ese límite.

## Microsoft 365 Copilot

1. Guarda la carpeta del kit en tu OneDrive o SharePoint.
2. En Copilot Chat, referencia la carpeta o sus archivos con el selector de archivos (el icono de adjuntar, o escribe `/` y elige los archivos).
3. Pega el prompt de arranque como primer mensaje.
4. Si Copilot toma pocos archivos a la vez, usa el archivo único `kit-architect.md`; o empieza por `00-raiz/eres-ha.md`, `EMPIEZA-AQUI.md` y la dimensión en la que vas a trabajar, y agrega los demás cuando el asistente los pida.

> En Word o Loop, pega `00-raiz/eres-ha.md` y el prompt de arranque en el panel de Copilot y trabaja desde ahí. Guarda los avances de vuelta en los archivos de la carpeta.

---

## Azure OpenAI

1. Si usas el playground con "Add your data" o un índice, sube la carpeta del kit como fuente.
2. Pon el contenido de `00-raiz/eres-ha.md` como mensaje de sistema, o pégalo al inicio de la conversación.
3. Pega el prompt de arranque como primer mensaje del usuario.
4. Guarda lo que el asistente produzca de vuelta en los archivos de la carpeta.

---

## Terminal (Codex, Claude Code u otro)

1. Abre la carpeta del kit como proyecto.
2. Pide: «ejecuta la habilidad empieza».
3. El asistente lee la identidad, la memoria y las dimensiones, y te entrega el reporte de arranque.

---

## Cualquier chat, sin subir carpetas

1. Pega el contenido de `00-raiz/eres-ha.md`.
2. Pega el prompt de arranque (está en `EMPIEZA-AQUI.md`).
3. Conforme avances, pega el archivo que el asistente te pida: una habilidad, una dimensión, una nota.

---

## Una nota que aplica a todas

Guarda siempre los avances de vuelta en los archivos de la carpeta. Ahí vive la memoria del sistema. Lo que quede solo en la conversación se pierde al cerrarla.
