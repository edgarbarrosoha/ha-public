# 02 · Comunidad

**Rol:** el habilitador social.
**Pregunta:** ¿A quién necesitamos y quién se beneficia?

La Comunidad es el mapa vivo de las personas e instituciones que rodean el trabajo: sus relaciones, sus intereses y su influencia. Sirve para coordinar quién decide qué.

## Qué vive en esta dimensión
- Las personas y equipos involucrados, con su rol.
- Stakeholders, clientes, proveedores, aliados.
- Quién decide, quién participa y quién se beneficia de cada cosa.

## Cómo poblarla
Lleva una ficha corta por actor relevante: quién es, qué le importa, qué decide. Se actualiza conforme entran o salen personas del trabajo.

## Qué evita
Decisiones que nadie adopta y fricción política por no ver a tiempo quién tenía que estar.
