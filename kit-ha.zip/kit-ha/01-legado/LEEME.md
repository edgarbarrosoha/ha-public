# 01 · Legado

**Rol:** la brújula estratégica.
**Pregunta:** ¿Qué queremos lograr que trascienda?

El Legado define qué significa ganar y en qué horizonte de tiempo. Gobierna a las demás dimensiones: todo lo que se hace debería poder responder a un objetivo que vive aquí.

## Qué vive en esta dimensión
- La visión y los objetivos de largo plazo.
- Lo que cuenta como éxito, y cómo se mediría.
- Las restricciones y los valores que no se negocian.

## Cómo poblarla
Escribe en uno o varios `.md` dentro de esta carpeta cuál es el norte. Si puedes, conviértelo en algo verificable: qué resultado, para cuándo, medido con qué. Cuando un proyecto pierda el rumbo, se vuelve aquí.

## Qué evita
Proyectos sueltos sin un norte común.
