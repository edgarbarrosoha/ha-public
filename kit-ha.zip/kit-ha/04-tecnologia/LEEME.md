# 04 · Tecnología

**Rol:** la infraestructura.
**Pregunta:** ¿Qué herramientas e infraestructura nos sostienen?

La Tecnología es el sistema socio-técnico que soporta el trabajo: datos, herramientas, integraciones, modelos de IA. Se mira como un conjunto coordinado, con sus piezas conectadas entre sí.

## Qué vive en esta dimensión
- El inventario de sistemas, datos y herramientas en uso.
- Cómo se conectan entre sí y qué reglas de uso tienen.
- Qué asistente de IA opera este kit y cómo (por ejemplo, Copilot sobre Azure).

## Cómo poblarla
Lleva una lista de lo que se usa y para qué. Cuando se incorpore una herramienta nueva, anótala aquí con su propósito. Mantén a la vista qué datos viven dónde.

## Qué evita
Herramientas inconexas que nadie coordina.
