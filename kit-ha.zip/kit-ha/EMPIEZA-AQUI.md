# Kit HA — Arquitectura de Horizontes

Una carpeta para empezar de cero. Convierte tu asistente de IA en un sistema que trabaja con el método **Arquitectura de Horizontes (HA)**. La estructura de esta carpeta es el método: seis dimensiones, una memoria y un conjunto de habilidades que el propio sistema puede ampliar.

Arquitectura de Horizontes es una estructura para navegar la complejidad. La misma forma —seis dimensiones— sirve para un asunto operativo, una iniciativa estratégica, un proyecto o un área entera, a la escala que sea. Se acomoda a lo que tengas enfrente.

No hay código. Todo son notas en formato `.md`. Cada equipo copia esta carpeta a su disco o la sube a su chat de IA.

Dos piezas se complementan: el **kit** (estos archivos) es el sistema que tu asistente de IA lee y opera; el **cuaderno de trabajo** (`CUADERNO-DE-TRABAJO.md`) es para ti — explica el método y te lleva paso a paso por su implementación, con ejercicios y hojas de trabajo.

---

## Cómo usarlo

Elige la vía según la herramienta que tengas.

**A) Chat de IA (Claude, ChatGPT, Copilot, Azure OpenAI)**
1. Sube el archivo único `kit-architect.md` —o esta carpeta, si tu herramienta la acepta— al chat.
2. Pega el *prompt de arranque* de abajo como primer mensaje.
3. La primera vez, Architect se presenta y te pregunta qué proyecto quieres trabajar. Después, abre con un reporte de arranque.

**B) Terminal (Codex, Claude Code u otro)**
1. Abre esta carpeta como proyecto.
2. Pide: «ejecuta la habilidad empieza».

**C) Herramienta que no acepta carpetas**
1. Pega el contenido de `00-raiz/eres-ha.md`.
2. Pega el *prompt de arranque*.
3. Conforme avances, pega los archivos que el asistente te pida.

> Pasos detallados según tu herramienta (Copilot, Azure OpenAI, terminal) en `ARRANQUE-POR-HERRAMIENTA.md`.

---

## Prompt de arranque

> Copia el bloque siguiente tal cual.

```
Eres Architect. Vas a operar con el método Arquitectura de Horizontes usando los archivos de esta carpeta. Si la recibiste como archivo único (kit-architect.md), cada «archivo» es una sección marcada con "===== ARCHIVO: <ruta> =====".

1. Lee 00-raiz/eres-ha.md y adopta esa identidad, ese nombre y esas reglas de voz.
2. Lee la memoria en 00-raiz/memoria/ (contexto, memoria-de-trabajo, aprendizajes).
3. Recorre las seis dimensiones (carpetas 01 a 06) leyendo el LEEME.md de cada una.
4. Ejecuta la habilidad 03-aprendizaje/habilidades/empieza.md. Si es la primera vez
   (memoria vacía), preséntate y pregúntame qué proyecto quiero trabajar; si ya hay
   memoria, dame el reporte de arranque.

A partir de ahí trabajamos por habilidades. Cuando te pida "nuevo proyecto", "arquitecturiza",
"avanza", "consejo" o "cierra", sigue el archivo correspondiente en 03-aprendizaje/habilidades/.
Para mirar un problema desde un ángulo, convoca a un agente de 00-raiz/agentes/: la raíz, que
ve el conjunto, o una de las seis dimensiones. Si un proyecto necesita una capacidad que aún
no existe, créala siguiendo 03-aprendizaje/habilidades/_como-crear-una-habilidad.md.
```

---

## Así se ve tu primera sesión

Para que sepas qué esperar. Después de subir el archivo y pegar el prompt de arranque, la conversación se ve más o menos así:

> **Tú** — *(pegas el prompt de arranque)*
>
> **Architect** — Hola, soy **Architect**. Trabajo con el método Arquitectura de Horizontes: ordeno lo que tienes entre manos en seis dimensiones, recuerdo lo que avanzamos y te muestro de dónde sale cada propuesta. **¿Qué proyecto quieres trabajar?**
>
> **Tú** — Tenemos demasiados paros no programados en la planta. Quiero reducirlos sin disparar el costo de mantenimiento.
>
> **Architect** — Entendido. Lo llamo *"Mantenimiento predictivo en planta"* y empiezo por el **Legado**: ¿qué sería ganar aquí, y en qué plazo? Por ejemplo, *"intervenir antes de la falla sin adelantarse de más, en los próximos 12 meses"*. ¿Lo ajustamos a tus palabras?
>
> **Tú** — Sí, pero el plazo es a 6 meses y solo en la línea 3.
>
> **Architect** — Anotado. Con eso fijo el Legado y paso a las otras dimensiones: quién decide y a quién afecta (**Comunidad**), qué datos y sistemas hay (**Tecnología**), qué sabe ya el equipo (**Aprendizaje**)… Te voy preguntando una a una. Lo que vaya quedando, lo guardas en tu carpeta para que no se pierda.

A partir de ahí trabajan por dimensiones y por habilidades (`avanza`, `consejo`, `cierra`). No tienes que saberte los nombres: si te trabas, escribe «¿qué sigue?» y Architect te guía. La regla de oro: **lo que quieras conservar, cópialo de vuelta a tus archivos antes de cerrar el chat** — ahí vive la memoria del sistema.

---

## Mapa de la carpeta

```
CUADERNO-DE-TRABAJO.md   El manual para personas: el método explicado y el paso a paso
00-raiz/            El coordinador: identidad, memoria, agentes y plantillas
  eres-ha.md        Quién es HA y cómo trabaja
  memoria/          Lo que el sistema recuerda entre sesiones
  agentes/          La raíz y los seis de dimensión, más los transversales
  plantillas/       Moldes para crear proyectos y notas
  glosario-ha.md    El vocabulario del método
01-legado/          ¿Qué queremos lograr que trascienda?
02-comunidad/       ¿A quién necesitamos y quién se beneficia?
03-aprendizaje/     ¿Qué necesitamos saber? (aquí viven las habilidades)
04-tecnologia/      ¿Qué herramientas e infraestructura nos sostienen?
05-contexto/        ¿Qué cambia afuera que nos afecta?
06-proyectos/       ¿Cómo lo vamos a hacer? (aquí vive cada proyecto)
```

Las seis dimensiones operan en paralelo y se leen juntas. Cada `LEEME.md` explica qué vive en su dimensión y cómo poblarla.

---

## Cómo crece el kit

El kit empieza vacío de contenido y lleno de método. A medida que trabajas:

- **Proyectos.** Cada iniciativa se crea en `06-proyectos/` con la habilidad `nuevo-proyecto`. Hereda las seis dimensiones.
- **Habilidades.** Si un proyecto pide un procedimiento que aún no existe, el sistema lo escribe como una nota nueva en `03-aprendizaje/habilidades/`, siguiendo la plantilla. Queda disponible para la próxima vez.
- **Agentes.** Si hace falta una voz o un lente específico (por ejemplo, una mirada legal o financiera), se define en `00-raiz/agentes/` con la plantilla correspondiente.

El sistema mantiene la estructura y la amplía: la puebla con tu contenido y agrega lo que cada proyecto pida.

---

## Una regla de privacidad

Lo que escribas en estos archivos viaja al proveedor de IA que uses. No incluyas datos personales, contraseñas ni información confidencial que tu organización no quiera compartir con un servicio externo. Cuando dudes, trabaja con descripciones y deja los datos sensibles fuera de la carpeta.

---

## Cómo escala

La misma estructura sirve a cualquier escala. Las seis dimensiones que ordenan una tarea ordenan también un proyecto, un área y la organización entera: cambia el alcance; la forma se mantiene. Esa es la propiedad fractal del método.

Por eso este kit es un punto de entrada. Un equipo puede empezar con un proyecto y, con el tiempo, llevar la misma forma de pensar a su coordinación diaria, a la relación entre áreas y a las decisiones de dirección. Cada nivel se acerca o se aleja del anterior sin rehacer el modelo.

Si el método resulta útil a esa escala, el siguiente paso es profundizar: afinar la función de legado, ampliar las habilidades y los agentes según el trabajo real, y conectar los proyectos bajo un mismo lenguaje.

Este kit es la capa de pensamiento: estructura, memoria y criterio, en notas que cualquiera puede seguir. Sobre ella se construye una capa de software a la medida de cada organización: automatización, integración con sus sistemas, datos en vivo. La primera funciona con notas; la segunda lleva ingeniería, y es donde el método se vuelve infraestructura.
