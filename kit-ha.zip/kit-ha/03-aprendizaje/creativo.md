# CREATIVO — cómo darle instrucciones a un modelo

CREATIVO es una forma de armar una instrucción para que un modelo de IA responda mejor. Cada letra es una pieza que conviene incluir.

- **C — Contexto.** La situación: de qué va y qué información de fondo necesita el modelo.
- **R — Rol.** Desde qué papel responde (un analista, un editor, un revisor).
- **E — Ejemplo.** Una muestra de cómo se ve una buena respuesta.
- **A — Audiencia.** Para quién es la respuesta.
- **T — Tarea.** Qué se le pide, en concreto.
- **I — Instrucciones.** Cómo hacerlo: pasos, límites, formato.
- **V — Voz.** El tono y el estilo.
- **O — Objetivo.** Qué se busca lograr con la respuesta.

No hace falta usar las ocho cada vez. Entre más claras estén Contexto, Tarea y Objetivo, mejor responde el modelo.

> En este kit, HA ya trabaja con esta lógica: lee el contexto desde la memoria, toma un rol (un agente) y produce con una tarea y un objetivo definidos. CREATIVO es útil cuando le hablas tú directamente al modelo.
