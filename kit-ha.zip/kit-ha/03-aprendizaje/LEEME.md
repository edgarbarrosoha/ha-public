# 03 · Aprendizaje

**Rol:** el motor evolutivo.
**Pregunta:** ¿Qué necesitamos saber o entrenar?

El Aprendizaje guarda las capacidades del sistema: lo que se sabe hacer y lo que conviene aprender. Aquí viven las **habilidades** —los procedimientos que el sistema repite— y el conocimiento que el trabajo va dejando.

## Qué vive en esta dimensión
- `habilidades/` — los procedimientos repetibles que el asistente ejecuta. El núcleo del kit trae cinco (`empieza`, `nuevo-proyecto`, `avanza`, `consejo`, `cierra`) y la guía para crear más.
- Conocimiento útil: lo que se aprendió de un proyecto, prácticas que funcionaron, cosas por estudiar.

## Cómo poblarla
Cuando un trabajo se repita igual, escríbelo como habilidad (ver `habilidades/_como-crear-una-habilidad.md`). Cuando algo se aprenda y aplique a más de un caso, va a los aprendizajes de la memoria.

## Qué evita
Depender de que una sola persona sepa cómo se hacen las cosas.
