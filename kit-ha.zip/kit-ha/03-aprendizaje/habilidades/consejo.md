# Habilidad: consejo

**Para qué sirve:** poner una decisión a prueba desde varias miradas antes de tomarla. En lugar de una sola respuesta, abre el problema con los agentes.

**Cuándo se usa:** ante una decisión que pesa, donde conviene ver el riesgo, los ángulos de cada dimensión y los supuestos antes de elegir.

## Pasos
1. Formula la decisión en una sola pregunta clara.
2. Convoca a los agentes que más pesan en esta decisión (en `00-raiz/agentes/`). Para un caso típico:
   - los **agentes de dimensión** que toca la decisión (legado, comunidad, tecnología, contexto…), cada uno desde su ángulo.
   - **revisión crítica** — los riesgos y el supuesto más frágil.
   - **primeros principios** — si el planteamiento se sostiene desde lo básico.
3. Mantén cada voz por separado. El valor está en que difieran.
4. Escribe una **síntesis**: dónde coinciden, dónde chocan, y qué queda como decisión abierta.
5. La persona decide. Registra la decisión y su porqué en la Zona B de `00-raiz/memoria/contexto.md`.

## Resultado
Una decisión vista desde varios ángulos, con sus tensiones a la vista, y el acuerdo final registrado. Si hace falta una mirada que el kit no trae (legal, financiera, de un sector), créala como agente nuevo antes de convocar.
