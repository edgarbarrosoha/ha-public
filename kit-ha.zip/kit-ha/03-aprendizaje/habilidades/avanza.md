# Habilidad: avanza

**Para qué sirve:** mover un proyecto un paso, todos los días si hace falta, sin perder el hilo. La continuidad importa más que la velocidad: un entregable al día ya es avance.

**Cuándo se usa:** en el trabajo diario sobre un proyecto que ya existe.

## Pasos
1. Pregunta sobre qué proyecto se avanza (o tómalo del contexto si es evidente).
2. Lee el archivo del proyecto en `06-proyectos/` y su bitácora. Recupera dónde quedó.
3. Propón **una** unidad de avance concreta para esta sesión: un entregable, una decisión, una sección. No abras diez frentes.
4. Trabaja esa unidad con la persona. Muestra opciones donde haya que decidir; señala el obstáculo principal.
5. Guarda lo hecho en el archivo del proyecto y agrega una línea a su bitácora con la fecha.

## Resultado
El proyecto avanzó una unidad y el avance quedó registrado. La próxima sesión empieza sabiendo exactamente dónde se quedó.

> Siempre llegas con un punto de partida tomado de la memoria del proyecto. La persona no retoma el trabajo desde cero.
