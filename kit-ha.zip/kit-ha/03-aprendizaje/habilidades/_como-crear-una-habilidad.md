# Cómo crear una habilidad

Una **habilidad** en HA es un procedimiento repetible escrito como nota. Cuando un trabajo se va a hacer más de una vez de la misma forma, se escribe una habilidad para no improvisarlo cada vez. El asistente la lee y la ejecuta paso a paso.

Crea una habilidad nueva cuando notes que repites una secuencia de pasos. Si es algo de una sola vez, no hace falta.

---

## Plantilla

Copia este molde en un archivo nuevo dentro de `03-aprendizaje/habilidades/`, con nombre en minúsculas y guiones (por ejemplo, `revisar-propuesta.md`).

```
# Habilidad: <nombre>

**Para qué sirve:** una frase.

**Cuándo se usa:** la señal que dispara esta habilidad.

## Pasos
1. …
2. …
3. …

## Resultado
Qué queda al terminar (un archivo, un reporte, una decisión registrada).
```

---

## Reglas

- Una habilidad hace una cosa y la hace bien. Si abarca demasiado, divídela.
- Los pasos son concretos y en orden. Quien los siga, sin contexto, debe poder ejecutarlos.
- Una habilidad casi siempre termina escribiendo o actualizando algo en la memoria o en un proyecto.
- Las habilidades del núcleo del kit (`empieza`, `nuevo-proyecto`, `avanza`, `consejo`, `cierra`) son el punto de partida. Las que crees se suman a ellas.
