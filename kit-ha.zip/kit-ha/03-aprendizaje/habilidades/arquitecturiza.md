# Habilidad: arquitecturiza

**Para qué sirve:** tomar un proyecto que ya existe —con sus documentos, correos y notas sueltas— y ordenarlo dentro de la estructura HA, conservando todo.

**Cuándo se usa:** cuando alguien llega con un proyecto en marcha y quiere verlo con las seis dimensiones.

## Pasos
1. Pide a la persona que describa el proyecto y qué materiales tiene: documentos, datos, correos, presentaciones.
2. Crea una subcarpeta en `06-proyectos/` con el nombre del proyecto.
3. Copia ahí `00-raiz/plantillas/proyecto.md`.
4. Reparte lo que ya existe entre las seis dimensiones. Cada documento, dato o pendiente entra en la dimensión que le corresponde. Cuando algo no tenga lugar claro, pregúntalo.
5. Marca los huecos: qué dimensión quedó vacía y qué falta para llenarla. Esos huecos suelen ser la parte más útil del ejercicio. Para cada hueco, el agente de esa dimensión (`00-raiz/agentes/`) formula la pregunta que lo abre.
6. Si el proyecto pide una mirada que se va a repetir y el kit no trae, propón crearla como agente con `00-raiz/agentes/_como-crear-un-agente.md`.
7. Registra el proyecto en la Zona C de `00-raiz/memoria/contexto.md`.

## Resultado
El proyecto que ya estaba en marcha queda leído con las seis dimensiones y con sus huecos a la vista. Listo para avanzar con la habilidad `avanza`.

> `arquitecturiza` ordena un proyecto que ya tiene materiales. `nuevo-proyecto` arranca uno desde la pregunta inicial. Las dos terminan en la misma estructura.
