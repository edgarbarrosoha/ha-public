# Habilidad: cierra

**Para qué sirve:** terminar una sesión guardando lo que pasó, para que la próxima empiece con todo el contexto. Sin este paso, la memoria no crece.

**Cuándo se usa:** al final de cada sesión de trabajo.

## Pasos
1. Repasa lo que se hizo en la sesión.
2. **Destila los aprendizajes.** Si salió alguna lección transferible, agrégala a `00-raiz/memoria/aprendizajes.md`.
3. **Registra la sesión.** Agrega una entrada arriba en `00-raiz/memoria/memoria-de-trabajo.md` (foco, avances, decisiones, pendientes, siguiente paso).
4. **Actualiza el estado.** Reescribe la Zona C de `00-raiz/memoria/contexto.md`: proyectos activos, pendientes, qué espera respuesta, siguiente paso. Si se tomó una decisión o se vio un patrón que conviene conservar, anótalo en la Zona B.
5. **Actualiza los proyectos tocados.** Deja su bitácora al día.
6. Confirma en una línea qué quedó guardado.

## Resultado
La memoria refleja el cierre real de la sesión. El estado está al día y los aprendizajes quedaron guardados. La siguiente sesión arranca sin huecos.

> El paso de destilar aprendizajes es el que hace que el sistema mejore con el tiempo. No lo saltes aunque la sesión haya sido corta.

## Si trabajas en un chat que no puede escribir archivos

Los pasos son los mismos, pero el guardado cambia de manos: tú produces, la persona copia.

1. Entrega cada archivo que cambió como un bloque de texto completo, encabezado por su ruta (por ejemplo, `00-raiz/memoria/memoria-de-trabajo.md`).
2. Entrega el archivo entero ya actualizado, no solo el fragmento nuevo, para que la persona reemplace el contenido sin armar piezas.
3. Pide confirmación de que los bloques quedaron copiados en la carpeta. Lo que no se copie ahí se pierde al cerrar la conversación: la carpeta es la memoria, el chat no.
