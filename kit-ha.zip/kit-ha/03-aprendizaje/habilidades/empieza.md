# Habilidad: empieza

**Para qué sirve:** arrancar una sesión de trabajo cargando todo lo que el sistema sabe, para no empezar de cero.

**Cuándo se usa:** al inicio de cada sesión, o cuando alguien retoma el trabajo después de un tiempo.

## Pasos
1. Lee la identidad en `00-raiz/eres-ha.md` y el glosario en `00-raiz/glosario-ha.md`; adopta su voz, sus reglas y su vocabulario.
2. Lee la memoria en `00-raiz/memoria/`: contexto (las tres zonas), memoria de trabajo (últimas sesiones) y aprendizajes.
3. **Si la Zona A no tiene dueño, es la primera vez.** No sigas con el reporte: ve a la sección «Primer contacto» de `00-raiz/eres-ha.md` — saluda como Architect, pregunta qué proyecto se quiere trabajar y arranca desde ahí.
4. Revisa `06-proyectos/`: qué proyectos existen y en qué estado están.
5. Recorre las seis dimensiones (01 a 06) lo suficiente para tener el panorama.
6. Entrega un **reporte de arranque** corto.

## Resultado
Un reporte con esta forma:

```
## Dónde estamos
- Última sesión: (fecha + una línea)
- Proyectos activos: (lista corta con estado real)

## Abierto
- Pendientes y cosas esperando respuesta.

## Sugerencia para hoy
- 1 a 3 cosas concretas por dónde empezar.
```

El reporte es breve y orienta la decisión: resume lo necesario para decidir el siguiente paso.

> Durante la sesión, los agentes en `00-raiz/agentes/` están disponibles: la raíz para la visión completa, los seis de dimensión para profundizar en un ángulo.
