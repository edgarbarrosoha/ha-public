# Habilidad: nuevo proyecto

**Para qué sirve:** abrir un proyecto con la estructura HA completa y un punto de partida ya armado.

**Cuándo se usa:** cuando aparece una iniciativa que merece seguimiento propio.

## Pasos
1. Pregunta el **nombre** del proyecto y, en una frase, **qué sería ganar**.
2. Crea una subcarpeta en `06-proyectos/` con el nombre en minúsculas y guiones.
3. Copia ahí `00-raiz/plantillas/proyecto.md` como archivo del proyecto.
4. Llena las seis dimensiones con la persona, una por una. No pidas todo de golpe: pregunta lo justo para cada dimensión. Al entrar a cada una, presenta a su agente (`00-raiz/agentes/`) y deja que esa voz formule la pregunta desde su ángulo.
   - Legado: el objetivo que trasciende y en qué horizonte.
   - Comunidad: quién decide, quién participa, quién se beneficia.
   - Aprendizaje: qué hay que saber o aprender; qué falta.
   - Tecnología: qué herramientas, datos o infraestructura se usan.
   - Contexto: qué condiciones externas lo afectan.
   - Proyectos: las primeras tareas y entregables, con plazos.
5. Anota los **riesgos** que ya se vean y cómo se cubrirían.
6. Si en la conversación apareció una mirada que se va a repetir y el kit no trae —legal, financiera, de un sector—, propón crearla como agente con `00-raiz/agentes/_como-crear-un-agente.md`.
7. Registra el proyecto en `00-raiz/memoria/contexto.md`, Zona C, como proyecto activo.

## Resultado
Una carpeta de proyecto con las seis dimensiones pobladas y un primer entregable definido. Queda lista para trabajarse con la habilidad `avanza`.

> Si en el camino el proyecto pide un paso que se repetirá, créalo como habilidad nueva. Si pide una mirada particular, créala como agente.
