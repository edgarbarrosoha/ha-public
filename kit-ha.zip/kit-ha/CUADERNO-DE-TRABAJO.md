# Cuaderno de trabajo — Arquitectura de Horizontes

*Cómo implementar HA en tu organización, paso a paso.*

---

## Cómo usar este cuaderno

Este cuaderno acompaña al kit HA. El kit es el sistema que tu asistente de IA lee y opera; este cuaderno es para ti. Explica el método, te lleva por su implementación en un proyecto real de tu empresa, y deja hojas de trabajo para que el ejercicio quede por escrito.

Dos rutas de lectura:

- **Si es tu primer contacto con HA:** lee en orden. Cada parte construye sobre la anterior y los ejercicios usan lo que ya respondiste.
- **Si ya operas sistemas de IA** (asistentes corporativos, agentes, RAG, copilotos): lee la Parte 1 y la Parte 2 para fijar el vocabulario, y salta a la Parte 6 — el paso a paso. Las partes 3 a 5 te sirven como referencia cuando una dimensión o un concepto pida profundidad.

Al terminar tendrás cinco cosas concretas:

1. Un reto de tu área formulado como **emprendimiento complejo**, con su definición de ganar.
2. Ese reto leído a través de las **seis dimensiones**, con sus huecos a la vista.
3. Un sistema operando: tu asistente de IA trabajando como **Architect** sobre tu proyecto, con memoria.
4. Al menos un **agente** definido para una mirada que tu proyecto necesita.
5. Tu **mapa de 90 días**: qué decisión recompones primero y qué no tocas todavía.

Lo que necesitas: este cuaderno, el kit (la carpeta que lo contiene), un asistente de IA que pueda leer un archivo, y un reto real. El reto es el ingrediente que nadie puede poner por ti.

---

# Parte 1 — El punto de partida: tu reto complejo

## 1.1 Qué es un emprendimiento complejo

HA llama **emprendimiento complejo** al proceso de buscar una transformación deseada en un fenómeno complejo — por una persona, una organización o una red. La definición tiene tres marcas:

- **Muchos actores.** Hay varias áreas, niveles o instituciones involucradas, con incentivos que no siempre coinciden.
- **Intensidad de datos.** La información existe, pero está repartida, incompleta o llega tarde a quien decide.
- **Evolución incierta.** El problema cambia mientras lo trabajas; lo que era cierto hace seis meses puede no serlo hoy.

Casi todo lo que importa en una empresa grande cumple las tres marcas. Algunos ejemplos del tipo de reto que este cuaderno tiene en mente:

- Una operación de manufactura que debe decidir **cuándo intervenir un equipo antes de que falle**, con datos de sensores por un lado, reportes de mantenimiento por otro, y la experiencia del técnico veterano en ninguno de los dos.
- Un grupo industrial con **varias unidades de negocio que no comparten lo que saben**: el mismo problema se resuelve tres veces, de tres formas, sin que ninguna unidad se entere de las otras dos.
- Una operación que debe **defender ante un consejo o un regulador cómo llegó a una cifra** — ambiental, financiera, de riesgo — y descubre que el camino entre los datos y el número reportado no está documentado.
- Un equipo de investigación y desarrollo cuyo **conocimiento científico no llega a producción**: lo que el laboratorio aprende se queda en el laboratorio.
- Una operación de servicios donde **los datos técnicos abundan y las decisiones de negocio llegan tarde**, porque nadie traduce lo primero en lo segundo a tiempo.

Ningún caso de este cuaderno se refiere a una empresa en particular. Si alguno se parece al tuyo, es porque la estructura del problema se repite entre sectores — y esa repetición es precisamente lo que el método aprovecha.

## 1.2 La pregunta que ordena todo lo demás

Antes de cualquier herramienta, una pregunta:

> **¿Tu organización usa la IA para hacer más rápido lo de siempre, o para decidir distinto?**

Acelerar lo de siempre tiene valor: correos que se redactan solos, minutas automáticas, resúmenes. Pero ese valor se agota pronto y lo obtiene cualquiera, porque las herramientas son las mismas para todos. El cambio de fondo está en otra parte: en la **arquitectura de decisión** — quién decide, con qué información, en qué momento, y con qué rastro. La unidad de trabajo deja de ser la tarea y pasa a ser la decisión.

HA trabaja en ese segundo terreno. Por eso el punto de partida del método es una decisión, y no un proceso a automatizar.

## 1.3 Ejercicio 1 — Elige tu reto

Piensa en una decisión importante de tu área que cumpla al menos dos de estas condiciones:

- [ ] Hoy se toma **tarde** o con **información incompleta**.
- [ ] Cruza **más de un área** (operación y finanzas; I+D y producción; técnico y comercial).
- [ ] El criterio para tomarla vive **en la cabeza de pocas personas**, no en la organización.
- [ ] Si la persona que mejor la entiende se fuera mañana, la calidad de la decisión caería.

Escríbela en una frase, con este molde:

> *"En mi área, la decisión de **[qué]** se toma **[cómo se toma hoy: tarde / por intuición / sin rastro / por una sola persona]**, y eso cuesta **[qué cuesta: paros, retrabajos, riesgo, oportunidades]**."*

Tu frase:

| Mi reto |
|---|
| &nbsp; |
| &nbsp; |

Esta frase es el material de trabajo de todo el cuaderno. Las hojas de trabajo del final parten de ella.

---

# Parte 2 — El método en una página

## 2.1 La estructura

**Arquitectura de Horizontes (HA)** es una estructura compartida para navegar la complejidad en alianza entre las personas y la inteligencia artificial. Mira cualquier trabajo a través de **seis dimensiones** y **dos ejes**, con la misma forma a cualquier escala.

**Los dos ejes:**

| Eje | Qué organiza |
|---|---|
| **Tiempo (no lineal)** | Todo dato y evento se clasifica como pasado (lecciones), presente (estado vivo) o futuro (escenarios). Una clasificación viva — distinta de un cronograma. |
| **Complejidad simultánea** | Las seis dimensiones operan a la vez y se afectan entre sí. En lugar de forzarlas a una sola fila, se coordinan. |

**Las seis dimensiones:**

| # | Dimensión | Pregunta que responde | Rol |
|---|---|---|---|
| 01 | **Legado** | ¿Qué queremos lograr que trascienda? | La brújula |
| 02 | **Comunidad** | ¿A quién necesitamos y quién se beneficia? | El habilitador social |
| 03 | **Aprendizaje** | ¿Qué necesitamos saber o desarrollar? | El motor evolutivo |
| 04 | **Tecnología** | ¿Qué herramientas e infraestructura nos sostienen? | La infraestructura |
| 05 | **Contexto** | ¿Qué cambia afuera que nos afecta? | El radar |
| 06 | **Proyectos** | ¿Cómo lo ejecutamos? | La acción |

**Los tres axiomas** — lo que se asume como dado, sin rediscutirlo caso por caso:

1. **Las seis dimensiones están siempre presentes.** En cualquier trabajo, a cualquier escala. Si una está vacía, eso señala un hueco real del proyecto, no un defecto del formato.
2. **El tiempo es no lineal y explícito.** Pasado, presente y futuro coexisten como categorías vivas.
3. **La estructura es fractal.** Una tarea, un proyecto, un área y la organización entera repiten la misma forma. Cambia el alcance; la forma se mantiene.

## 2.2 Por qué una estructura fija ayuda (en lugar de estorbar)

La analogía de referencia es el **pentagrama**. Antes de la notación musical moderna, la música se transmitía de forma vaga y efímera. Cinco líneas fijas habilitaron el aprendizaje sistemático, la colaboración amplia y composiciones infinitas sobre una estructura compartida. Las líneas no limitan la música; la hacen posible a escala.

HA funciona igual. Como las dimensiones son invariantes:

- **Toda idea tiene lugar de inmediato.** No gastas energía en decidir cómo estructurar cada problema; solo en poblarlo. El esfuerzo se va a pensar el contenido, no a diseñar el contenedor.
- **Todo hueco es visible de inmediato.** Una dimensión vacía se nota. En la práctica, los huecos suelen ser el hallazgo más útil de la primera sesión.
- **Todo se vuelve comparable.** Un proyecto personal, una iniciativa de área y un programa corporativo comparten la misma gramática. Lo aprendido en uno se transfiere al otro sin perderse en la traducción.

Una advertencia que conviene hacer temprano: HA no simplifica la complejidad — la **estabiliza**. El problema sigue siendo difícil; lo que cambia es que deja de ser desorientador. Hay diferencia entre un problema duro y un problema duro en el que además no sabes dónde estás parado.

## 2.3 El reparto humano–IA

El corazón del método es una división del trabajo:

> **Las personas definen el qué y el porqué. El sistema trabaja el cómo.**

Tú traes la intención: el objetivo, lo que cuenta como ganar, los valores que no se negocian. El sistema mapea la complejidad, encuentra caminos, nombra obstáculos y muestra opciones — siempre dejando ver cómo llegó a cada propuesta. El pensamiento crítico del sistema apunta a los obstáculos del camino, nunca a la intención de quien decide. Las personas deciden; el sistema propone.

De este reparto se derivan dos propiedades que pedirle a cualquier sistema de IA que participe en decisiones:

- **Trazabilidad.** Cada afirmación que sostiene una propuesta puede seguirse hasta su fuente, su fecha y el proceso que la produjo. Cuando el dato no existe, el sistema lo dice; no lo inventa. Esto convierte la IA en algo que puedes defender ante un consejo, un auditor o un regulador.
- **Memoria.** Lo trabajado persiste entre sesiones. La próxima conversación empieza donde quedó la anterior, con las decisiones y sus porqués registrados. Un chat sin memoria produce respuestas; un sistema con memoria acumula criterio.

---

# Parte 3 — Las seis dimensiones, una por una

Cada sección sigue el mismo formato: qué pregunta responde la dimensión, qué vive en ella, cómo se ve cuando está débil en una empresa, y un micro-ejercicio sobre tu reto. Responde los micro-ejercicios aunque sea con una línea; alimentan la hoja de trabajo C.

## 3.1 Legado — ¿Qué queremos lograr que trascienda?

La brújula del proyecto: define **qué significa ganar** y en qué horizonte de tiempo. Cuando se puede, incluye cómo se mediría. HA la llama la **función de legado**: el conjunto de objetivos, con sus pesos y umbrales, que gobierna las decisiones del proyecto. Todo lo demás se evalúa contra ella.

**Qué vive aquí:** el objetivo que justifica el proyecto, el horizonte (¿seis meses? ¿tres años?), los criterios de éxito, lo que no se negocia.

**Señales de que está débil en tu organización:**
- Hay actividad intensa y nadie puede decir, en una frase, qué sería ganar.
- Los pilotos de IA se evalúan por si "funcionaron técnicamente", no por si movieron una decisión que importa.
- Dos áreas trabajan el mismo tema con definiciones de éxito incompatibles, y nadie lo ha notado.

**En el reto de mantenimiento** (el ejemplo que desarrollamos a lo largo del cuaderno): ganar podría ser *"intervenir antes de la falla sin adelantarse de más — menos paros no programados sin disparar el costo de mantenimiento preventivo"*. Observa que la definición ya contiene la tensión central del problema (parar de más cuesta; parar de menos cuesta más), y eso es deseable: una función de legado útil carga sus propias tensiones en lugar de esconderlas.

> **Micro-ejercicio.** Para tu reto: ¿qué sería ganar, en una frase? ¿En qué horizonte? ¿Qué indicador te diría que se logró? Si no existe ese indicador hoy, anótalo — acabas de encontrar tu primer hueco.

## 3.2 Comunidad — ¿A quién necesitamos y quién se beneficia?

El mapa vivo de personas e instituciones: quién decide, quién participa, quién se beneficia, quién puede bloquear. Con sus relaciones e incentivos, no solo sus nombres. La pregunta operativa detrás: **¿quién decide qué, y por qué confiaría en este sistema?**

**Qué vive aquí:** el mapa de actores, los protocolos de coordinación, los incentivos de cada quien, las resistencias previsibles.

**Señales de debilidad:**
- Se despliegan herramientas que técnicamente funcionan y nadie usa.
- La decisión formal la firma una persona, pero la decisión real la toma otra, y el proyecto solo habló con la primera.
- El costo de equivocarse recae en alguien que no participó en el diseño.

**En el reto de mantenimiento:** el supervisor decide si se para la línea; el operador ve las señales primero; el director de operaciones carga el costo del paro y el de la falla. Si el sistema avisa antes pero el supervisor sigue decidiendo por costumbre, la decisión se tomará tarde igual. La dimensión de Comunidad pesa aquí tanto como la técnica — el obstáculo más común en este tipo de proyecto es de confianza, no de modelo.

> **Micro-ejercicio.** Para tu reto: ¿quién toma la decisión hoy? ¿Quién carga el costo si sale mal, en cada uno de los dos sentidos (actuar de más / actuar de menos)? ¿Quién tendría que confiar en un sistema nuevo para que algo cambie?

## 3.3 Aprendizaje — ¿Qué necesitamos saber o desarrollar?

El motor evolutivo: las capacidades, los conocimientos y las lecciones. Incluye el conocimiento explícito (manuales, wikis, bases documentadas) y el tácito — el que vive en personas y se nota cuando faltan. Su trabajo de fondo: que la organización deje de depender de héroes individuales.

**Qué vive aquí:** qué hay que saber para lograr el legado, qué de eso ya se tiene y dónde, qué falta, qué lecciones de intentos anteriores conviene no repetir.

**Señales de debilidad:**
- El conocimiento crítico no sobreviviría la salida de tres personas concretas. (Haz la prueba: nómbralas.)
- Se repiten errores documentados en informes que nadie relee.
- Cada unidad resuelve por su cuenta problemas que otra ya resolvió.

**En el reto de unidades que no comparten:** el grupo industrial del ejemplo no tiene un problema de falta de conocimiento — tiene un problema de circulación. Cada unidad sabe cosas que a las otras les costaría meses aprender. La dimensión de Aprendizaje convierte eso en una pregunta operable: ¿qué sabe cada nodo, en qué formato vive ese saber, y qué tendría que pasar para que viaje?

> **Micro-ejercicio.** Para tu reto: el criterio con el que hoy se decide, ¿está escrito en algún lado o vive en la cabeza de alguien? Si está escrito, ¿quién lo lee? Si vive en cabezas, ¿de cuántas?

## 3.4 Tecnología — ¿Qué herramientas e infraestructura nos sostienen?

La infraestructura: datos, sistemas, integraciones, IA. Pensada como **sistema socio-técnico** — las herramientas y la manera en que la gente las usa, juntas. Lo que esta dimensión evita tiene nombre en casi toda empresa: la pila de herramientas inconexas, compradas en momentos distintos, que no se hablan entre sí.

**Qué vive aquí:** el inventario de sistemas y datos relevantes al reto, qué mide cada fuente y cada cuánto, dónde están las integraciones rotas, qué infraestructura pediría el siguiente paso.

**Señales de debilidad:**
- Los datos existen pero llegan a quien decide en un formato o en un momento que no sirve.
- Hay licencias de IA comparadas y comparadas de nuevo, y ningún caso de uso anclado a una decisión.
- Nadie puede decir si las fallas pasadas quedaron registradas con fecha y contexto, o solo "lo que se reparó".

**En el reto de la cifra defendible:** la operación que debe sostener un número ante un regulador descubre que el dato final es correcto pero el camino no es reconstruible — pasó por tres hojas de cálculo y dos correos. La dimensión de Tecnología pregunta por ese camino: no solo si el dato existe, sino si su linaje se puede seguir. La trazabilidad se decide aquí, en la arquitectura, no en el reporte final.

> **Micro-ejercicio.** Para tu reto: ¿qué fuentes de datos lo tocan? Para cada una: ¿qué mide, cada cuánto, y quién la ve? ¿El historial de decisiones pasadas (y sus resultados) está registrado en algún lado?

## 3.5 Contexto — ¿Qué cambia afuera que nos afecta?

El radar: las condiciones externas — mercado, regulación, tecnología ajena, macroeconomía — que afectan al proyecto sin pedirle permiso. Su modo de operación es el escaneo dinámico: alertas, escenarios y restricciones vigentes, no un análisis anual que envejece en una carpeta.

**Qué vive aquí:** las restricciones regulatorias y contractuales vigentes, los movimientos del sector que cambiarían las premisas del proyecto, los escenarios contra los que conviene probar las decisiones.

**Señales de debilidad:**
- Una regulación anunciada con dieciocho meses de anticipación "sorprende" a la organización.
- El proyecto asume condiciones (precios, proveedores, normas) que ya cambiaron.
- Nadie tiene asignado mirar afuera; todos miran adentro.

**En el reto de I+D a producción:** el equipo de investigación trabaja con un horizonte largo; producción, con el trimestre. El contexto externo — una norma técnica nueva, un material que un competidor ya escaló — afecta a ambos de formas distintas, y ninguno de los dos lo vigila para el otro. La dimensión de Contexto da un lugar común a ese radar.

> **Micro-ejercicio.** Para tu reto: ¿qué condición externa, si cambiara el próximo año, invalidaría tu plan actual? ¿Quién la está vigilando hoy? (Si la respuesta es "nadie", anótalo como hueco.)

## 3.6 Proyectos — ¿Cómo lo ejecutamos?

La acción: iniciativas, tareas, recursos, riesgos y entregables. Aquí se prioriza, se ejecuta, se mide y se cierra el ciclo. Lo que esta dimensión evita: la actividad sin resultado — mucho movimiento que no mueve ningún indicador del Legado.

**Qué vive aquí:** los entregables concretos con responsable y fecha, los riesgos con su cobertura, la bitácora de lo decidido y lo avanzado.

**Señales de debilidad:**
- Los proyectos avanzan pero nadie puede conectarlos con un objetivo que trascienda.
- Hay diez frentes abiertos y ninguno cerrado en meses.
- Las decisiones tomadas no quedan registradas, así que se vuelven a discutir.

**Regla práctica de HA para esta dimensión:** una unidad de avance por sesión. Un entregable, una decisión, una sección — completa y registrada. La continuidad importa más que la velocidad.

> **Micro-ejercicio.** Para tu reto: si solo pudieras producir un entregable en las próximas dos semanas, ¿cuál movería más la decisión? (Pista: en la mayoría de los retos de decisión, el primer entregable útil es dejar por escrito el criterio actual y confrontarlo con los datos de los últimos casos. De ahí sale si el problema es de datos, de criterio o de quién decide.)

## 3.7 Las seis juntas

Tres principios que cruzan todo lo anterior:

1. **Operan en paralelo.** No son fases. Un cambio en Tecnología toca a Comunidad; una alerta de Contexto reordena Proyectos. A esto el método le llama complejidad simultánea, y es la razón de tratarlas juntas.
2. **Ninguna se deriva de otra.** Cada una captura algo que las demás no ven. Por eso son seis y no una lista flexible: quitar una deja un ángulo ciego; agregar una redundante diluye el foco.
3. **El Legado gobierna.** Las otras cinco se evalúan contra la función de legado. Sin ella, las dimensiones son un inventario; con ella, son una brújula.

---

# Parte 4 — Los dos ejes en la práctica

## 4.1 El tiempo no lineal

En HA, el tiempo es una clasificación viva — algo distinto de un cronograma. Cada dato, evento o documento del proyecto pertenece a una de tres categorías:

| Categoría | Qué contiene | Para qué sirve |
|---|---|---|
| **Pasado** | Lecciones, historial, decisiones tomadas y sus resultados | Que lo aprendido no se vuelva a pagar |
| **Presente** | El estado vivo: qué está abierto, qué espera, quién tiene la pelota | Decidir con la foto de hoy, no con la del trimestre pasado |
| **Futuro** | Escenarios, riesgos, compromisos, señales tempranas | Probar las decisiones de hoy contra los mañanas plausibles |

La utilidad práctica: cuando una decisión se discute, las tres capas están disponibles a la vez. "¿Ya intentamos esto?" (pasado), "¿qué está corriendo ahora mismo?" (presente) y "¿contra qué escenario estamos apostando?" (futuro) dejan de ser tres reuniones distintas.

> **Ejercicio 2.** Toma seis elementos de tu reto — datos, documentos, eventos, rumores de pasillo — y clasifícalos: ¿pasado, presente o futuro? Nota cuáles te costó clasificar: suelen ser los que la organización tampoco tiene claros.

## 4.2 La complejidad simultánea y el cruce

El segundo eje se vuelve tangible en una operación concreta: el **cruce** — una pregunta que ninguna dimensión puede responder sola.

Ejemplos de cruce, sobre los retos de la Parte 1:

- *"Si adelantamos la intervención del equipo (Proyectos), ¿quién absorbe el costo del paro programado (Comunidad) y qué dice el contrato de suministro sobre ventanas de mantenimiento (Contexto)?"*
- *"Si la unidad A comparte su modelo de pronóstico con la unidad B (Aprendizaje), ¿qué infraestructura común se necesita (Tecnología) y quién gobierna las diferencias de criterio (Comunidad)?"*
- *"Si la norma ambiental cambia el año próximo (Contexto), ¿qué datos tendríamos que estar capturando desde hoy (Tecnología) para que la cifra de 2027 sea defendible (Legado)?"*

El valor del cruce está en que fuerza a las dimensiones a hablarse. La mayoría de los errores caros en proyectos complejos viven exactamente ahí: cada área hizo bien su parte y nadie miró la costura.

> **Ejercicio 3.** Escribe un cruce de tu reto: una pregunta que toque al menos tres dimensiones. Guárdala — la vas a usar en el paso 6 de la implementación, como prueba de fuego de tu sistema.

## 4.3 La propiedad fractal

El tercer axioma dice que la estructura se repite a toda escala. En la práctica significa que este cuaderno te sirve tres veces:

- **Hoy**, sobre un reto de tu área (la escala de este ejercicio).
- **Después**, sobre el área entera: las mismas seis preguntas, con alcance mayor.
- **Eventualmente**, sobre la organización: cada proyecto repite la forma por dentro, y los niveles se conectan sin rediseñar nada.

Esa conexión entre niveles tiene una regla: **cada proyecto debe poder justificar su existencia hacia arriba.** ¿A qué objetivo del área suma este proyecto? ¿Y ese objetivo del área, a qué objetivo de la organización? Un proyecto que no puede responder está huérfano — o se conecta, o se cierra. Esta cascada de propósito convierte el mapa de dimensiones en algo más útil: una forma de saber, en cualquier momento, si la actividad de abajo sigue sirviendo a la intención de arriba.

---

# Parte 5 — La alianza con la máquina

## 5.1 Qué hace cada quien

El kit que acompaña este cuaderno convierte la teoría anterior en un sistema operable con cualquier asistente de IA. La identidad del sistema se llama **Architect**, y su contrato de trabajo es el reparto de la Parte 2: tú pones el qué y el porqué; Architect trabaja el cómo, propone con trazabilidad, y registra lo que se decide.

Tres piezas componen el sistema:

**Agentes.** Un agente es una voz con un encargo claro: una nota que describe cómo debe pensar el asistente cuando lo convocas. El kit trae la **raíz** (que coordina y ve el conjunto), los **seis de dimensión** (cada uno mira desde su ángulo) y dos transversales: **revisión crítica** (riesgos y supuestos frágiles) y **primeros principios** (¿se sostiene esto desde lo básico?). Los agentes proponen; las personas deciden.

**Habilidades.** Procedimientos repetibles escritos como notas: `empieza` (arrancar sesión con todo el contexto), `nuevo-proyecto` y `arquitecturiza` (abrir u ordenar un proyecto), `avanza` (una unidad de avance por sesión), `consejo` (varias miradas sobre una decisión que pesa), `cierra` (guardar lo que pasó). No se improvisa cada vez un trabajo que se repite.

**Memoria.** Tres zonas: identidad (quién es el dueño, casi no cambia), criterio (decisiones, patrones y correcciones acumuladas con fecha) y estado actual (la foto de hoy, se reescribe al cerrar cada sesión). Más una memoria de trabajo con el registro de sesiones. La memoria es la diferencia entre un chat y un sistema: lo que se decide queda, con su porqué, y la siguiente sesión arranca donde quedó la anterior.

## 5.2 La ontología generativa — el sistema crece con el trabajo

La propiedad más importante del kit para el largo plazo: **cuando un trabajo pide una mirada o un procedimiento que no existe, el sistema lo crea.** Tu proyecto de mantenimiento pedirá tarde o temprano una mirada de fiabilidad; el de la cifra defendible, una mirada de auditoría; el de I+D, una de transferencia tecnológica. Ninguna viene en el kit — y no hace falta: se definen en una nota de diez líneas siguiendo la plantilla, y quedan disponibles para siempre.

Esto significa que el sistema de cada empresa diverge del kit inicial, y eso es lo esperado. El kit trae el método; tu organización le pone el contenido y las miradas propias. A los seis meses, dos empresas que partieron del mismo kit tienen sistemas distintos — cada uno moldeado por sus retos. La estructura (dimensiones, ejes, axiomas) es lo único que permanece idéntico, y es lo que permite que sigan siendo comparables y que lo aprendido viaje.

## 5.3 Lo que el sistema no hace

Para calibrar expectativas, con la misma honestidad que el método pide:

- **No decide.** Propone, muestra el rastro, y la decisión queda en personas. Esto aplica también cuando la propuesta es buena: la autoridad para ejecutar es un diseño organizacional, no un default técnico.
- **No sabe lo que no se le ha dado.** Si el criterio de decisión vive en la cabeza de un técnico y nadie lo escribe, el sistema no lo va a adivinar. El trabajo de captura es humano.
- **No sustituye la conversación difícil.** Si dos áreas tienen incentivos opuestos, el sistema lo hace visible (eso ya es mucho), pero resolverlo es trabajo de quien dirige.
- **No es mágicamente confiable.** Es tan confiable como su trazabilidad. Por eso el método la exige: cuando no puedas seguir el rastro de una afirmación, no la uses para decidir.

Y una regla de privacidad permanente: lo que escribas en los archivos del sistema viaja al proveedor de IA que uses. Datos personales, contraseñas e información que tu organización no compartiría con un servicio externo quedan fuera. Cuando dudes, trabaja con descripciones y deja los datos sensibles fuera de la carpeta.

## 5.4 Gobernar el sistema — la capa avanzada

Mientras trabajas con un solo asistente, la gobernanza cabe en una conversación. Cuando los agentes se multiplican — varios trabajando en paralelo, algunos arrancando solos en un horario, otros delegando partes a subagentes — las preguntas cambian de naturaleza: pasan de la herramienta a la organización. Tres reglas sostienen cualquier sistema de agentes, del tamaño que sea:

- **Permisos.** Qué ejecuta un agente sin preguntar y qué requiere tu visto bueno. Se define antes de trabajar, no en el momento. Una línea sana sigue el reparto del método: lo reversible y del lado del cómo (ordenar, resumir, comparar, proponer) corre solo; lo irreversible o del lado del qué y el porqué (enviar, borrar, comprometer, gastar) escala a una persona.
- **Memoria.** Qué recuerda cada agente, qué comparten entre sí y qué muere con la conversación. La memoria compartida es lo que convierte agentes sueltos en un sistema; decidir qué entra a ella es una decisión de gobierno.
- **Trazabilidad.** Poder reconstruir quién hizo qué, con qué fuente y por qué. Con un agente es deseable; con una flota es lo único que separa un sistema auditable de una caja negra repartida.

Cuando hay varios agentes, los patrones de coordinación son los mismos que usarías con un equipo humano: **en paralelo** (varios exploran a la vez, cada uno una fuente o un ángulo), **en cadena** (la salida de uno es la entrada del siguiente — el handoff de la Parte 6), **verificación cruzada** (un agente intenta refutar el hallazgo de otro; lo que sobrevive al escéptico es más confiable) y **panel** (varias propuestas independientes sobre la misma decisión, comparadas y sintetizadas). Elegir el patrón es una decisión de arquitectura: la pregunta de fondo pasa de qué modelo usar a cómo se organiza el trabajo entre ellos.

Esta capa concentra el valor a mediano plazo. Los modelos mejoran cada pocos meses y los renta cualquiera; la capa que los coordina — tus datos, tu criterio escrito, tus reglas de quién decide — se construye y es tuya. Una flota de agentes sin reglas produce ruido en paralelo. Con arquitectura, se vuelve una capa de pensamiento colectivo al servicio de una sola visión: la del dueño del reto.

> **Micro-ejercicio.** Escribe las tres reglas de tu sistema: (1) qué puede hacer solo, (2) qué debe preguntarte siempre, (3) qué merece quedar en la memoria del proyecto. En el kit, estas reglas viven en la identidad de Architect (`00-raiz/eres-ha.md`) — ábrela y ajústalas; es una nota de texto, igual que todo lo demás.

---

# Parte 6 — Paso a paso: implementa HA en tu proyecto

Esta es la parte central del cuaderno. Ocho pasos: los primeros cinco se completan en una sesión de trabajo (en el taller o en tu oficina); los últimos tres establecen el ritmo de las semanas siguientes. Cada paso indica qué haces tú y qué hace el sistema.

## Paso 1 — Nombra el reto y define ganar

*(Si hiciste los ejercicios 1 y el micro-ejercicio de Legado, ya lo tienes.)*

Escribe dos frases:

1. **El reto:** la decisión que se toma tarde o con información incompleta (Ejercicio 1).
2. **Ganar:** qué cambiaría, en qué horizonte, medido cómo (micro-ejercicio 3.1).

No avances sin la segunda frase. Un proyecto sin función de legado produce actividad sin dirección, y un sistema de IA la acelera — más actividad, igual de sin dirección.

## Paso 2 — Prepara tu entorno

Necesitas el kit y una herramienta que lo lea.

1. **Consigue la carpeta del kit** (quien te dio este cuaderno te la compartió; este cuaderno vive dentro de ella).
2. **Elige tu herramienta.** Cualquier asistente de IA que acepte archivos sirve: el asistente corporativo de tu empresa, o uno comercial. La guía `ARRANQUE-POR-HERRAMIENTA.md` del kit trae los pasos exactos para los más comunes. Si tu herramienta no acepta carpetas — la mayoría no lo hace — usa el archivo único `kit-architect.md`: todo el kit en un solo archivo.
3. **Haz la prueba de un minuto.** Sube el archivo y pide: *"resume en una línea qué es Arquitectura de Horizontes según este archivo"*. Si responde con el contenido, estás listo. Si no — por permisos o políticas de tu organización — resuélvelo con tu área de TI antes de la sesión de trabajo, no durante.

## Paso 3 — Primer contacto

Pega el **prompt de arranque** (está en `EMPIEZA-AQUI.md`) como primer mensaje. La primera vez, Architect se presenta y te hace la única pregunta que necesita para empezar:

> *Hola, soy Architect. [...] ¿Qué proyecto quieres trabajar?*

Respóndele con tus dos frases del Paso 1. A partir de tu respuesta, Architect elige el camino: si tu reto ya tiene materiales (documentos, datos, intentos previos), usará `arquitecturiza` — ordenar lo que existe dentro de las seis dimensiones. Si es una iniciativa nueva, usará `nuevo-proyecto`. Los dos caminos terminan en la misma estructura.

En esta primera sesión, Architect también te pedirá llenar la identidad del sistema (quién es el dueño, qué alcance tiene). Dos minutos, una sola vez.

## Paso 4 — Puebla las dimensiones

Architect te llevará dimensión por dimensión, presentando al agente de cada una y haciendo la pregunta que la abre. Tus respuestas de la Parte 3 (los micro-ejercicios) son exactamente lo que va a pedirte — tenlas a la mano.

Reglas de juego para esta conversación:

- **Responde lo que sabes; declara lo que no.** "No sé quién vigila esa norma" es una respuesta valiosa: queda registrada como hueco.
- **No busques completitud.** Una primera pasada con cuatro dimensiones pobladas y dos huecos honestos vale más que seis dimensiones rellenadas con generalidades.
- **Exige rastro.** Si Architect propone algo y no ves de dónde salió, pregúntale. Si no puede mostrarte el camino, trátalo como hipótesis, no como dato.

## Paso 5 — Lee los huecos

Al terminar la pasada, pide el resumen: ¿qué dimensión quedó vacía o débil? Los huecos son el primer entregable real del ejercicio. Patrones frecuentes y lo que suelen significar:

| Hueco | Lectura probable |
|---|---|
| Legado débil | El proyecto existe por inercia o por moda; nadie definió ganar |
| Comunidad vacía | Se diseñó la solución sin mapear quién decide y quién debe confiar en ella |
| Aprendizaje vacío | El conocimiento crítico vive en personas; riesgo de fuga alto |
| Tecnología confusa | Datos existen pero su linaje y frecuencia no; trazabilidad imposible hoy |
| Contexto vacío | Nadie mira afuera; el plan asume que el mundo se queda quieto |
| Proyectos hipertrofiada | Mucha actividad, poca conexión con el legado — el patrón más común |

Anota tus huecos en la hoja de trabajo C. El mapa de 90 días (Parte 8) sale en buena medida de ahí.

## Paso 6 — Convoca miradas y crea las que falten

Con las dimensiones pobladas, usa el sistema para lo que un chat suelto no hace:

1. **Lanza tu cruce** (el del Ejercicio 3): la pregunta que toca tres dimensiones. Observa cómo el sistema la responde consultando lo que tú mismo poblaste, con rastro. Esa es la consulta cruzada — la operación que justifica toda la estructura.
2. **Para una decisión que pesa, pide un `consejo`:** varios agentes opinan por separado — los de dimensión que toque la decisión, revisión crítica con los riesgos, primeros principios con los supuestos — y el sistema sintetiza dónde coinciden y dónde chocan. El valor está en las diferencias: una decisión que sobrevive a varias miradas en conflicto llega más sólida a tu comité.
3. **Crea tu primer agente propio.** Tu proyecto ya habrá pedido una mirada que el kit no trae. Defínela con la plantilla (`_como-crear-un-agente.md`): propósito, cuándo convocarlo, cómo se comporta, qué evita. Diez líneas. Desde ese momento, esa mirada está disponible cada vez que el proyecto la necesite.

## Paso 7 — Cierra y guarda

Al final de la sesión, pide `cierra`. El sistema repasa lo hecho, destila aprendizajes, registra la sesión y actualiza el estado. **Este paso separa el sistema del chat:** sin cierre, todo lo anterior se evapora al cerrar la ventana.

Si trabajas en un chat que no escribe archivos (el caso más común), Architect te entregará los archivos actualizados como bloques de texto con su ruta — cópialos de vuelta a tu carpeta. La carpeta es la memoria real del sistema; treinta segundos de copiado compran la continuidad de todo lo demás.

## Paso 8 — Establece el ritmo

El método vive o muere en la cadencia, y la cadencia recomendada es modesta a propósito:

- **Sesiones cortas y regulares** — `empieza`, una unidad de avance con `avanza`, `cierra`. Treinta minutos bien cerrados superan a tres horas sin registro.
- **Una unidad de avance por sesión.** Un entregable, una decisión, una sección. La continuidad le gana a la intensidad: el sistema acumula criterio sesión a sesión, y esa acumulación — decisiones, correcciones, patrones con fecha — es lo que ningún despliegue de licencias puede comprar hecho.
- **Revisa el criterio acumulado cada pocas semanas.** La zona de criterio de la memoria (decisiones, patrones, correcciones) es una radiografía de cómo decide tu área. Leerla en frío enseña más que cualquier reporte.

---

# Parte 7 — De proyecto a organización

## 7.1 La secuencia realista

La adopción que funciona va de adentro hacia afuera:

1. **Un proyecto, una persona** (tú, después de este taller). Costo: horas. Riesgo: ninguno.
2. **Un proyecto, un equipo.** El sistema se vuelve compartido: el mapa de actores, la memoria y los agentes son del equipo, no de una persona. Aquí aparece la primera exigencia organizacional: disciplina de cierre — alguien debe ser dueño de que la memoria se mantenga.
3. **Un área, varios proyectos.** Cada proyecto repite la estructura por dentro (propiedad fractal); el área tiene su propia capa con sus seis dimensiones, y los proyectos justifican su existencia hacia arriba (cascada). En este nivel el método empieza a responder preguntas de dirección: ¿qué proyectos sirven a qué objetivos? ¿cuáles son huérfanos?
4. **La organización.** Misma forma, alcance mayor. A esta escala, el método suele pedir infraestructura: integración con sistemas y datos en vivo, control de acceso, automatización de flujos. Esa es una capa de ingeniería que se construye sobre la capa de pensamiento — y solo tiene sentido cuando los niveles 1 a 3 ya demostraron valor con notas y disciplina.

La advertencia del nivel 4, dicha sin rodeos: **comprar la infraestructura sin practicar el método produce un tablero más, junto a los que ya nadie consulta.** La secuencia importa porque cada nivel construye el criterio que el siguiente necesita.

## 7.2 Qué pedirle a tu organización (y qué no todavía)

Para sostener los niveles 1 y 2, necesitas poco y conviene pedirlo explícitamente:

- **Acceso:** que tu herramienta de IA corporativa pueda leer archivos del equipo (la prueba de un minuto, resuelta con TI).
- **Tiempo protegido:** la cadencia del Paso 8 — sesiones cortas, regulares, con cierre.
- **Permiso para escribir lo que se decide.** Suena trivial; en muchas organizaciones registrar decisiones con su porqué es contracultural. Es la pieza que más valor acumula.

Lo que conviene no pedir todavía: presupuesto de plataforma, integraciones, un "proyecto de transformación". Todo eso llega mejor cuando puedas mostrarlo funcionando en pequeño — con tu proyecto, tu memoria acumulada y tu mapa de 90 días como evidencia.

---

# Parte 8 — El mapa de 90 días

El entregable final del taller, y de este cuaderno. Cuatro preguntas, respondidas por escrito. La cuarta es la que más se agradece a los noventa días.

**1. ¿Qué decisión recompongo primero?**
La decisión de tu reto — o una más pequeña dentro de ella — donde el cambio de arquitectura (quién decide, con qué información, con qué rastro) es visible en semanas. Criterio de elección: que duela lo suficiente para que importe, y sea acotada lo suficiente para que se logre.

**2. ¿Qué conocimiento capturo?**
El saber tácito más frágil que tu ejercicio reveló (micro-ejercicio de Aprendizaje: ¿cuántas cabezas?). Noventa días dan para capturar el criterio de una decisión: entrevistar a quien lo tiene, escribirlo, validarlo con casos pasados, dejarlo en la dimensión de Aprendizaje del proyecto.

**3. ¿Qué NO toco todavía?**
Tan importante como las anteriores. Candidatos típicos: la decisión políticamente cargada (resuélvela después de acumular credibilidad), la integración técnica grande (nivel 4 antes de tiempo), el proceso que funciona razonablemente (no gastes tu ventana de cambio ahí). Escribirlo te protege del alcance que crece solo.

**4. ¿Qué necesito de mi organización?**
Lo de la Parte 7.2: acceso, tiempo, permiso. Con nombre de quién lo otorga.

| Mapa de 90 días | Respuesta | Primer paso (fecha) |
|---|---|---|
| Decisión que recompongo | &nbsp; | &nbsp; |
| Conocimiento que capturo | &nbsp; | &nbsp; |
| Lo que no toco todavía | &nbsp; | — |
| Lo que necesito (y de quién) | &nbsp; | &nbsp; |

---

# Parte 9 — Errores comunes

Recopilados de implementaciones reales del método; ninguno es hipotético.

**1. Confundir licencias con sistema.** Desplegar herramientas de IA a toda la plantilla y declarar transformación. Sin arquitectura de decisión, el resultado es lo de siempre, más rápido. La pregunta de control: ¿qué decisión cambió de dueño, de información o de rastro?

**2. Saltarse la función de legado.** Pilotos que arrancan porque la tecnología está disponible. Sin definición de ganar, no hay forma de saber si funcionó — y todo piloto "funciona" para alguien.

**3. Tratar las dimensiones como formato.** Llenar las seis casillas una vez, archivarlas, y seguir trabajando como siempre. Las dimensiones son un instrumento de consulta viva: se pueblan, se consultan al decidir, se actualizan al cerrar. Un mapa que no se consulta vuelve a ser papel.

**4. Trabajar sin memoria.** Usar el asistente en conversaciones sueltas, sin cierre ni registro. Cada sesión re-explica el contexto; nada se acumula. La señal: a los dos meses no puedes mostrar qué decisiones se tomaron ni por qué.

**5. Sobre-automatizar antes de tiempo.** Pasar de "el sistema propone" a "el sistema ejecuta" sin pasar por el periodo donde las propuestas se validan contra la realidad. La autoridad se gradúa: monitorear, alertar, proponer, ejecutar — en ese orden, y cada escalón se gana con historial.

**6. Ignorar la dimensión de Comunidad.** El patrón de falla más frecuente en proyectos técnicamente exitosos: el sistema funciona, la decisión mejora en el papel, y quien decide no lo usa porque nadie lo sentó a la mesa de diseño. Si solo puedes cuidar una dimensión más allá de la obvia, cuida esa.

**7. Esperar al plan perfecto.** El método se aprende operándolo en pequeño, no diseñándolo en grande. Una persona, un proyecto, treinta minutos por sesión. Lo demás escala desde ahí.

---

# Parte 10 — Preguntas frecuentes

**¿Esto reemplaza nuestra metodología de proyectos (PMO, ágil, stage-gate)?**
No compite con ellas. HA opera como meta-estructura: organiza el pensamiento y la decisión alrededor de los proyectos; tu metodología de ejecución sigue gobernando cómo se ejecutan. La dimensión de Proyectos se conecta con lo que ya uses.

**¿Por qué seis dimensiones y no cinco, o diez?**
Las seis capturan ángulos que no se derivan uno de otro — propósito, actores, conocimiento, infraestructura, entorno y ejecución. En la práctica del método, quitar una deja decisiones ciegas en ese ángulo, y las candidatas a "séptima dimensión" (riesgo, finanzas, cultura) resultan vivir dentro de las existentes: el riesgo se reparte entre Contexto y Proyectos; las finanzas, entre Legado (criterios) y Proyectos (recursos); la cultura, en Comunidad y Aprendizaje.

**¿Qué pasa con nuestros datos sensibles?**
La regla del kit: lo que escribas viaja a tu proveedor de IA. Trabaja con descripciones y deja los datos sensibles fuera. Para uso organizacional serio, el criterio se formaliza con tu área de seguridad: qué clasificación de información puede entrar al sistema, en qué herramienta (la corporativa suele tener garantías contractuales que las comerciales no), y qué se queda siempre fuera.

**¿Cuánta gente necesita saber esto para que sirva?**
Una. El método rinde desde un practicante con un proyecto. Crece mejor por contagio que por mandato: alguien muestra su sistema funcionando — su memoria, sus agentes, su cruce respondido con rastro — y otros lo quieren. La adopción por decreto produce el error 3.

**¿Esto depende de un proveedor de IA en particular?**
No. El kit es texto plano y el método es independiente del modelo. El proveedor es intercambiable; lo que no es intercambiable es lo que tu práctica acumula — la memoria, el criterio, los agentes propios. Esa acumulación es tuya, vive en tus archivos, y se lleva a donde tú vayas.

**Soy escéptico de los marcos de moda. ¿Por qué este no es uno más?**
El escepticismo es razonable y el método lo comparte: ninguna estructura resuelve un problema por sí sola. La apuesta de HA es más modesta y más verificable — que una estructura fija y compartida reduce el costo de pensar juntos (humanos entre sí, y humanos con máquinas), igual que la notación musical redujo el costo de componer juntos. La prueba está en el uso: si a los noventa días tu memoria acumulada no te dice nada que no supieras, el método no te sirvió, y ese resultado también es información.

---

# Parte 11 — Glosario

Los términos del método, para uso común del equipo. Cuando todos los usan igual, se deja de discutir cómo estructurar el trabajo y se pasa a hacerlo.

| Término | Definición |
|---|---|
| **Arquitectura de Horizontes (HA)** | Estructura compartida para navegar la complejidad en alianza entre personas e IA: seis dimensiones, dos ejes, misma forma a cualquier escala. |
| **Emprendimiento complejo** | Proceso de buscar una transformación deseada en un fenómeno complejo: muchos actores, intensidad de datos, evolución incierta. |
| **Arquitectura de decisión** | Quién decide, con qué información, en qué momento y con qué rastro. El terreno donde la IA cambia algo de fondo. |
| **Las seis dimensiones** | Legado, Comunidad, Aprendizaje, Tecnología, Contexto, Proyectos. Siempre presentes; operan en paralelo. |
| **Los dos ejes** | Tiempo no lineal (pasado-presente-futuro como clasificación viva) y complejidad simultánea (las dimensiones coordinándose). |
| **Los tres axiomas** | Las seis dimensiones siempre están; el tiempo es no lineal; la estructura es fractal. Se asumen para no rediscutir el marco en cada caso. |
| **Función de legado** | La definición de ganar: objetivos, horizonte y medida. Gobierna las decisiones del proyecto. |
| **Complejidad simultánea** | Las dimensiones no se atienden por turnos: un cambio en una toca a las demás. |
| **Cruce** | Pregunta que ninguna dimensión responde sola. Donde viven los errores caros — y las consultas más valiosas. |
| **Estructura fractal** | La misma forma se repite en una tarea, un proyecto, un área y la organización. |
| **Cascada (de propósito)** | La conexión entre niveles: cada proyecto justifica su existencia hacia arriba, y la evidencia de abajo refina los objetivos de arriba. |
| **Trazabilidad** | Que cada afirmación pueda seguirse hasta su fuente, fecha y proceso. Condición para decidir con IA sin exponerse. |
| **Memoria** | Lo que el sistema conserva entre sesiones: identidad, criterio acumulado y estado actual, más el registro de trabajo. |
| **Agente** | Una voz con un encargo claro, que se convoca para mirar un problema desde un ángulo. Propone; no decide. |
| **Habilidad** | Procedimiento repetible escrito como nota: empieza, avanza, consejo, cierra y los que tu práctica agregue. |
| **Ontología generativa** | La capacidad del sistema de crear lo que le falta — un agente, una habilidad — cuando el trabajo lo pide, conservando la estructura. |
| **Consejo** | Varias miradas convocadas sobre una misma decisión, mantenidas separadas para que difieran, con síntesis de coincidencias y choques. |
| **Gobernanza de agentes** | Las reglas del sistema: qué ejecuta un agente solo, qué escala a personas, qué memoria comparten y qué rastro dejan. Se diseña antes de trabajar. |
| **Orquestación** | Cómo se organiza el trabajo entre varios agentes: en paralelo, en cadena, con verificación cruzada o en panel. |
| **Pensamiento colectivo** | Varias inteligencias — personas y agentes — coordinadas por una arquitectura común, al servicio de una sola visión. |
| **Unidad de avance** | Lo que una sesión produce: un entregable, una decisión, una sección. Completa y registrada. |
| **Architect** | La identidad del sistema en el kit: la voz que opera el método contigo. |
| **Mapa de 90 días** | El compromiso de salida: qué decisión recompongo, qué conocimiento capturo, qué no toco, qué necesito. |

---

# Parte 12 — Hojas de trabajo

Para llenar a mano o copiar a tus archivos. Las hojas A-D alimentan tu sesión con Architect (pasos 3-5); la E es tu salida (Parte 8); la F se usa cada vez que el proyecto pida una mirada nueva.

## Hoja A — El reto

| Campo | Respuesta |
|---|---|
| La decisión que se toma tarde o con información incompleta | &nbsp; |
| Cómo se toma hoy (quién, con qué, cuándo) | &nbsp; |
| Qué cuesta tomarla así | &nbsp; |
| Áreas que cruza | &nbsp; |

## Hoja B — Función de legado

| Campo | Respuesta |
|---|---|
| Qué sería ganar (una frase, con su tensión incluida) | &nbsp; |
| Horizonte de tiempo | &nbsp; |
| Cómo se mediría | &nbsp; |
| ¿Existe hoy ese indicador? Si no, quién lo construiría | &nbsp; |
| Lo que no se negocia | &nbsp; |

## Hoja C — Las seis dimensiones de mi reto

| Dimensión | Lo que sé | Hueco detectado |
|---|---|---|
| 01 Legado | &nbsp; | &nbsp; |
| 02 Comunidad | &nbsp; | &nbsp; |
| 03 Aprendizaje | &nbsp; | &nbsp; |
| 04 Tecnología | &nbsp; | &nbsp; |
| 05 Contexto | &nbsp; | &nbsp; |
| 06 Proyectos | &nbsp; | &nbsp; |

## Hoja D — El cruce

| Campo | Respuesta |
|---|---|
| Mi pregunta de cruce (toca ≥3 dimensiones) | &nbsp; |
| Dimensiones que toca | &nbsp; |
| Quién debería poder responderla hoy (y no puede) | &nbsp; |

## Hoja E — Mapa de 90 días

| Pregunta | Respuesta | Primer paso (fecha) |
|---|---|---|
| ¿Qué decisión recompongo primero? | &nbsp; | &nbsp; |
| ¿Qué conocimiento capturo? | &nbsp; | &nbsp; |
| ¿Qué NO toco todavía? | &nbsp; | — |
| ¿Qué necesito de mi organización (y de quién)? | &nbsp; | &nbsp; |

## Hoja F — Ficha de agente nuevo

*(El molde completo está en el kit: `00-raiz/agentes/_como-crear-un-agente.md`.)*

| Campo | Respuesta |
|---|---|
| Nombre del agente | &nbsp; |
| Propósito: qué aporta esta voz que las demás no | &nbsp; |
| Cuándo convocarlo | &nbsp; |
| Cómo se comporta: qué prioriza al mirar | &nbsp; |
| Qué evita | &nbsp; |

---

*Este cuaderno acompaña al kit HA — Arquitectura de Horizontes. El kit trae el sistema; el cuaderno, el camino. La práctica la pones tú.*
