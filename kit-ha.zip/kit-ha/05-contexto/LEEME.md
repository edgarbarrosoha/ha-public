# 05 · Contexto

**Rol:** la sensibilidad del entorno.
**Pregunta:** ¿Qué cambia afuera que nos afecta?

El Contexto es el escaneo de las condiciones externas: mercado, regulación, economía, tecnología, movimientos de otros actores. Es lo que pasa fuera de control directo pero pesa en las decisiones.

## Qué vive en esta dimensión
- Indicadores, normas, eventos y tendencias que afectan el trabajo.
- Escenarios de lo que podría pasar y sus señales de alerta.
- Notas de reuniones, llamadas y lecturas (material de contexto).

## Cómo poblarla
Guarda aquí lo que llega de afuera y conviene recordar, con la plantilla de nota (`00-raiz/plantillas/nota.md`). Revisa cada tanto qué cambió y qué restricción nueva aplica.

## Qué evita
Decidir mirando solo hacia adentro y perder de vista lo que se mueve afuera.
