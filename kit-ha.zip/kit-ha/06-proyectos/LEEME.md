# 06 · Proyectos

**Rol:** la ejecución.
**Pregunta:** ¿Cómo lo vamos a hacer?

Proyectos es donde pasa la acción: las iniciativas concretas, sus tareas, recursos, riesgos y entregables. Cada proyecto repite la estructura HA a su escala —tiene sus propias seis dimensiones dentro—, porque la estructura es fractal.

## Qué vive en esta dimensión
- Una subcarpeta por proyecto, con su archivo de proyecto y su bitácora.
- Lo que cada proyecto produce: entregables, avances, decisiones.

## Cómo poblarla
No crees proyectos a mano. Usa la habilidad `nuevo-proyecto`: pregunta el nombre y qué sería ganar, crea la subcarpeta y llena las seis dimensiones contigo. Después se trabaja con `avanza` y se mantiene su bitácora al día.

## Qué evita
Mucha actividad sin resultado. Cada proyecto se ata a un objetivo del Legado y se mide.

---

(Aún no hay proyectos. El primero se crea con la habilidad `nuevo-proyecto`.)
